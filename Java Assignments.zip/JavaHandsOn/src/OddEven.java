import java.util.Scanner;

public class OddEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int size = s.nextInt();
		System.out.println("Enter the numbers");
		int arr[] = new int[size];
		for(int i=0 ; i<size; i++) {
			arr[i] = s.nextInt();
		}
		
		for(int i=0; i<size; i++) {
			if(arr[i]%2==0)
				System.out.println("Even");
			else
				System.out.println("Odd");
		}


	}

}
