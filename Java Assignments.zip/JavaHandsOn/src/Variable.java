public class Variable {
	private int id;		//class variable
	private String name;//instance variable
	private String dept;
	private String university;
	
	private float percent;
	
	public void percentage(float[] marks, float maxMarks) {
		int length = marks.length;	//local variable
		float sum = 0;
		for(int i=0; i<length; i++) {
			sum+=marks[i];
		}
		this.percent = (sum/(maxMarks*length))*100;
	}

	public Variable(int id, String name, String dept) {
		super();
		this.id = id;
		this.name = name;
		this.dept = dept;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getUniversity() {
		return university;
	}

	public void setUniversity(String university) {
		this.university = university;
	}

	public float getPercent() {
		return percent;
	}

	public void setPercent(float percent) {
		this.percent = percent;
	}
}
