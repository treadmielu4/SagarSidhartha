
public class StringMatches {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "Welcome to Jumanji";
		String s2 = "Jumanji";
		System.out.println(s1.regionMatches(11, s2, 0, 7));


	}

}
