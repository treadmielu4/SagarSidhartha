import java.util.Scanner;

public class AreaPerimeterCircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the radius of circle");
		int rad = sc.nextInt();
		double area = 3.14*rad*rad;
		System.out.println("Area Of Circle is: "+area);
		double perimeter = 2*3.14*rad;
		System.out.println("Perimeter Of Circle is: "+perimeter);
		sc.close();


	}

}
