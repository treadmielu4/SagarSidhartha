import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int fact = 1;
		System.out.println("Enter the no you want to find factorial of :");
		int n = sc.nextInt();
		while(n>0) {
			fact = fact*n;
			n--;
		}
		System.out.println(fact);


	}

}
