import java.util.Scanner;

public class LastIndexOfString
{
	public static void main(String[] arg)
	{
		String str;
		String ch;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string :");
	 	str=sc.nextLine();
		
	 	System.out.println("Enter the letter to know its last index :");
	 	ch=sc.next();
	 	System.out.println(str.lastIndexOf((String) ch));
	 	sc.close();

	
	}
}