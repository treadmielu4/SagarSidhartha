
public class SubstringOfString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "There are various buddhists monasteries in Nepal.";
        String str1 = str.substring(2,5);
        System.out.println("old = " + str);
        System.out.println("new = " + str1);


	}

}
