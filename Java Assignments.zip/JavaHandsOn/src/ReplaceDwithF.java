import java.util.Scanner;

public class ReplaceDwithF {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a string");
		String str = in.nextLine();
		System.out.println("Replacing D with F: "+str.replace("d", "f"));


	}

}
