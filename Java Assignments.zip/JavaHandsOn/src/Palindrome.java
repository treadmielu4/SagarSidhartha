import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a no");
		int num = sc.nextInt();
		int rem,sum=0,z=num;
		while(z>0) {
			rem = z%10;
			sum=sum*10 + rem;
			z = z/10;
		}
		if(sum==num)
			System.out.println("Palindrome");
		else
			System.out.println("Not Palindrome");


	}

}
