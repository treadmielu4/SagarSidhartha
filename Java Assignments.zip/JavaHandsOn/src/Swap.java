import java.util.Scanner;

public class Swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x, y, z;
		   Scanner sc = new Scanner(System.in);
		   
		   System.out.println("Enter the value of x: ");
		   x = sc.nextInt();
		   System.out.println("Enter the value of y: ");
		   y = sc.nextInt();

		   z = x;
		   x = y;
		   y = z;

		   System.out.println(" Swapped values are : x= " + x + " and y= " + y);
		   sc.close();


	}

}
