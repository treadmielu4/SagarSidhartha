
public class ReplaceFoxwithCat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "The quick brown fox jumps over the lazy dog.";
        String str1 = str.replaceAll("fox", "cat");                
        System.out.println("Old String: " + str);
        System.out.println("New String: " + str1);


	}

}
