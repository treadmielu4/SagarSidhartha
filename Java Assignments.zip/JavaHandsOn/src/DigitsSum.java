import java.util.Scanner;

public class DigitsSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = sc.nextInt();
		int rem,sum=0;
		while(num>0) {
			rem = num%10;
			sum = sum + rem;
			num = num/10;
		}
		System.out.println("Sum of digits of an integer is: "+sum);


	}

}
