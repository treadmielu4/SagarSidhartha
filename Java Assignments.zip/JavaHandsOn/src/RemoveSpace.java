import java.util.Scanner;

public class RemoveSpace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str ;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter The String");
		str=sc.nextLine();
		String str1 =str.trim();
		System.out.println("Old:" + " " + str +"  ");
		System.out.println("New:" + " " + str1);


	}

}
