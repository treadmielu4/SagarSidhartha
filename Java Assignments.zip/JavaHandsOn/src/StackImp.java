
import java.util.Stack;

public class StackImp {

	public static void main(String[] args) {
		
		Stack<String> s = new Stack<>();
		
		//PUSH
		s.push("Winter");
		s.push("Is");
		s.push("Coming");
		
		System.out.print(s);
		System.out.println();
		
		//POP
		s.pop();
		System.out.print(s);
		System.out.println();
		
		//PEEK
		s.peek();
		System.out.print(s);
		System.out.println();
		
		//ISEMPTY
		System.out.println(s.isEmpty());
		

	}

}
