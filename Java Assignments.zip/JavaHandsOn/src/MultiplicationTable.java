import java.util.Scanner;

public class MultiplicationTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = in.nextInt();
		
		//WHILE LOOP
		int i = 1;
		while(i<=10) {
			int mult = num*i;
			System.out.println(+num+"*"+i+"="+mult);
			i++;
		}
		
		//FOR LOOP
		for(int j=1; j<=10; j++) {
			int mult = num*j;
			System.out.println(+num+"*"+j+"="+mult);
		}
		
		
		//DO-WHILE LOOP
		int k = 1;
		do {
			int mult = num*k;
			System.out.println(+num+"*"+k+"="+mult);
			k++;
		}
		while(k<=10);


	}

}
