import java.util.Scanner;

public class UpperCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
	     System.out.print("Enter a String: ");
		 String str = s.nextLine();
		 str = str.toUpperCase();
		 System.out.println(str); 


	}

}
