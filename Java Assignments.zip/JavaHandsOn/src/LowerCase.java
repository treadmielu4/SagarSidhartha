import java.util.Scanner;

public class LowerCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string");
		String str = sc.nextLine();
		System.out.println("String Entered:"+str);
		System.out.println("After converting to lowercase:"+str.toLowerCase());


	}

}
