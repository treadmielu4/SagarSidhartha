import java.util.Scanner;

public class ArmstrongNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter a number");
		int num = s.nextInt();
		int original,rem,total=0;
		original=num;
		while(original!=0) {
			rem = original%10;
			total = total + rem*rem*rem;
			original = original/10;
		}
		if(total==num)
			System.out.println(num +" is an armstrong number");
		else
			System.out.println(num +" is not an armstrong number");
		
		s.close();



	}

}
