import java.util.Scanner;

public class CharacterArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str ;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter The String");
		str=sc.nextLine();
		char[] arr = str.toCharArray();
		
		System.out.println(arr);
		


	}

}
